import fffserial
import mpu6050
import time
import RPi.GPIO as GPIO

DEVICE = '/dev/ttyUSB0'
I2C_ADRESS = 0x68
WIDTH = 28
HEIGHT = 13
BUZZER = 7

GPIO.setmode(GPIO.BOARD)
GPIO.setup(BUZZER, GPIO.OUT)

disp = fffserial.SerialDisplay(WIDTH, HEIGHT, DEVICE, buffered=True)
mpu = mpu6050.MPU6050(i2c_address=I2C_ADRESS)

last_update_moth = time.time()
MOTH_FREQ = 0.6

last_update_debug = time.time()
DEBUG_FREQ = 1

levels = [
[
    '############################',
    '#     #            #       #',
    '#  M  #  M       M #       #',
    '#     #      #     #       #',
    '#            #             #',
    '#            #             #',
    '#            #             #',
    '#         M  #     #       #',
    '#    #       #     #       #',
    '#    #       #     #       #',
    '#    #       #     #   S   #',
    '#    #       #     #       #',
    '############################'
],
[
    '############################',
    '#     #                    #',
    '#     #                    #',
    '#     #  M                 #',
    '#            #########     #',
    '#     ########             #',
    '#            #             #',
    '#    #    M  #     #       #',
    '#    #       #     #       #',
    '#    #       #     #       #',
    '#    #       #  M  #   S   #',
    '#  M #       #     #       #',
    '############################'
],
[
    '############################',
    '#     #                    #',
    '#  M  #  M       M         #',
    '#     #                    #',
    '#     #                    #',
    '############################',
    '#            #             #',
    '#         M  #             #',
    '#            #             #',
    '#            #             #',
    '#            #         S   #',
    '#            #             #',
    '############################'
],
[
    '############################',
    '#     #                    #',
    '#  M  #  M  #    M  #      #',
    '#     #################### #',
    '#     #                    #',
    '### ############### ########',
    '#            #             #',
    '#         M  #             #',
    '#            #             #',
    '#            #             #',
    '#            #         S   #',
    '#            #             #',
    '############################'
]
]
moth_count = 4
current_level = 0
level = levels[current_level]
start_pos = 25, 10
posx, posy = start_pos

def main():
    global posx, posy, last_update_debug

    #posx, posy = 25, 10
    velx, vely = 0, 0
    while True:
        rot = mpu.get_xyz_rotation()
        _xrot, xrot_scaled = rot['x']
        xrot_scaled -= 38
        xrot_scaled *= -1
        _yrot, yrot_scaled = rot['y']
        yrot_scaled -= 7
        #yrot_scaled *= -1

        if abs(xrot_scaled) > 0.5: velx += xrot_scaled / 500
        if abs(yrot_scaled) > 0.5: vely += yrot_scaled / 500
    
        if posx < 0 or posx > WIDTH-1: velx = 0
        if posy < 0 or posy > HEIGHT-1: vely = 0

        if empty(posx + velx, posy):
            posx += velx
        else:
            velx = 0
        if empty(posx, posy + vely):
            posy += vely
        else:
            vely = 0

        posx = max(0, min(WIDTH-1, posx))
        posy = max(0, min(HEIGHT-1, posy))

        try_catch_moth(posx, posy)

        time.sleep(0.01)
        output(posx, posy)

        if time.time() - last_update_debug > DEBUG_FREQ:
            print("POS", round(posx, 1), round(posy,1), 
                '\tVEL', round(velx,1), round(vely,1), 
                "\trot_scaled", round(xrot_scaled,1), round(yrot_scaled,1))
            last_update_debug = time.time()

def try_catch_moth(x, y):
    global moth_count, current_level, level, posx, posy

    intx, inty = int(x), int(y)
    if level[inty][intx] == 'M':
        row_new = list(level[inty])
        row_new[intx] = ' '
        level[inty] = "".join(row_new)
        moth_count -= 1

        if moth_count == 0:
            # beep
            for _ in range(300):
                GPIO.output(BUZZER, True)
                time.sleep(0.001)
                GPIO.output(BUZZER, False)
                time.sleep(0.001)
            current_level = (current_level + 1) % len(levels)
            if current_level == 0:
                exit(0)
            level = levels[current_level]
            moth_count = 4
            posx, posy = start_pos


def empty(x, y):
    return \
        0 <= x < WIDTH and 0 <= y < HEIGHT and \
        level[int(y)][int(x)] in (' ', 'M')

def unclear():
    for x in range(WIDTH):
        for y in range(HEIGHT):
            disp.px(x, y, True)
        

def output_level():
    x, y = 0, 0
    global last_update_moth
    restart_moth_timer = False

    for row in level:
        x = 0
        for col in row:
            if col == '#':
                disp.px(x, y, True)
            elif col == ' ':
                disp.px(x, y, False)
            elif col == 'M':
                if time.time() - last_update_moth > MOTH_FREQ:
                    disp.px(x, y, True)
                    restart_moth_timer = True
                else:
                    disp.px(x, y, False)
            
            x += 1
        y += 1
    
    if restart_moth_timer:
        last_update_moth = time.time()

def output(x, y):
    disp.clear()
    output_level()
    intx, inty = int(x), int(y)
    if 0 <= intx < WIDTH and 0<= inty < HEIGHT:
        disp.px(intx, inty, True)

    disp.show()

    s = '|'
    for i in range(WIDTH):
        if intx == i: 
            s += '*'
        else:
            s += ' '

    print(s + '|')

if __name__ == '__main__':
    main()
