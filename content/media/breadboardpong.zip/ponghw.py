import time
import smbus


class PHW:

    def __init__(self, i2c_address = 0x20, busnumber = 1):
        assert busnumber in [0, 1]

        self.i2c_address = i2c_address
        self.smbus = smbus.SMBus(busnumber)
        # configure default registers
        self._regs = {'conf': {'A': 0x00, 'B': 0x01},
                      'input': {'A': 0x12, 'B': 0x13},
                      'output': {'A': 0x14, 'B': 0x15}}
        self.config_inout('A', 0b00000011)
        self.config_inout('B', 0)

    def config_inout(self, bankab, value):
        assert bankab in ['A', 'B']
        reg = self._regs['conf'][bankab]
        self.smbus.write_byte_data(self.i2c_address, reg, value)

    def write_value(self, bankab, value):
        assert bankab in ['A', 'B']
        reg = self._regs['output'][bankab]
        self.smbus.write_byte_data(self.i2c_address, reg, value)

    def read_value(self, bankab):
        assert bankab in ['A', 'B']
        reg = self._regs['input'][bankab]
        return self.smbus.read_byte_data(self.i2c_address, reg)

p = PHW()

def led_an(nr):
    assert nr in range(14)
    #print(nr)
    if nr <= 5:
        bank1 = 'A'
        bank2 = 'B'
        wert = 2**(nr+2)
    else:
        bank1 = 'B'
        bank2 = 'A'
        wert = 2**(nr-6)
    p.write_value(bank1, wert)
    p.write_value(bank2, 0)

def taster_gedrueckt(nr):
    assert nr in range(2)
    bank = 'A'
    wert = p.read_value(bank)
    return (wert & 2**nr) == 2**nr
