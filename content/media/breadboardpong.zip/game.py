#!/usr/bin/env python3

import ponghw
import time


class Game:
    def __init__(self, numleds=16, sleep_time=0.1):
        self.numleds = numleds
        self.led_an = 0
        self.direction = 1  # +1 or -1
        self.sleep_time = sleep_time
        self.initial_sleep_time = sleep_time

    def reset(self):
        self.led_an = 0
        self.direction = 1
        self.sleep_time = self.initial_sleep_time

    def next_led(self):
        self.led_an = self.led_an + self.direction

    def bounce(self):
        self.direction *= -1
        self.sleep_time *= 0.9

    def led_at_player(self, playernr):
        assert playernr in [0, 1]

        if playernr == 0:
            return 0 <= self.led_an <= 2
        elif playernr == 1:
            return self.numleds-3 <= self.led_an <= self.numleds-1

    def blink_led(self, count):
        centerled = self.numleds // 2
        for _ in range(count):
            ponghw.led_an(centerled)
            time.sleep(self.sleep_time)
            ponghw.led_an(centerled + 1)
            time.sleep(self.sleep_time)

    def player_lost_game(self):
        return self.led_an < 0 or self.led_an >= self.numleds

    def run(self):
        last_update = time.time()
        while True:
            # handle input
            if ponghw.taster_gedrueckt(0) and self.led_at_player(0) and self.direction < 0:
                self.bounce()
            if ponghw.taster_gedrueckt(1) and self.led_at_player(1) and self.direction > 0:
                self.bounce()

            if time.time() - last_update > self.sleep_time:
                # update display
                self.next_led()
                if self.player_lost_game():
                    print("player lost game")
                    self.blink_led(5)
                    self.reset()

                ponghw.led_an(self.led_an)

                last_update = time.time()


if __name__ == "__main__":
    g = Game(numleds=14, sleep_time=0.3)
    g.run()
